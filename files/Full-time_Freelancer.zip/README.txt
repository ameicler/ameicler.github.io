Thank you for downloading Full-time Freelancer. 

If you have any questions please don’t hesitate to email me: hello@davidyeiser.com


READING ON KINDLE
—·—·—·—·—·—·—·—·—·—·—·—

1. To read the book on your Kindle just email the .mobi file to your device’s email address. If you’ve never done this it’s easy: you just add the .mobi file directly as an attachment and send. The subject of the email can be anything, it doesn’t affect how it appears on your Kindle.

2. This email address can be found in the Send-to-Kindle Email section under Settings —> Device Options —> Personalize your Kindle.

(In the iOS app version of Kindle it’s directly under Settings.)


READING ON 
MOBILE DEVICE OR TABLET
—·—·—·—·—·—·—·—·—·—·—·—

1. Open the .ePub file in iBooks.

Or,
2. Follow the READING ON KINDLE instructions with your native Kindle app.

Or,
3. Open the PDF on your device.